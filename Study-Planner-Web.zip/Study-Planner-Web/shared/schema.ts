import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  targetHoursPerWeek: integer("target_hours_per_week").notNull().default(5),
  color: text("color").notNull().default("#3b82f6"),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  subjectId: integer("subject_id").references(() => subjects.id),
  title: text("title").notNull(),
  scheduledDate: timestamp("scheduled_date").notNull(),
  durationMinutes: integer("duration_minutes").notNull().default(60),
  isCompleted: boolean("is_completed").notNull().default(false),
  priority: integer("priority").notNull().default(3), // 1 (low) to 5 (high)
});

export const studySessions = pgTable("study_sessions", {
  id: serial("id").primaryKey(),
  subjectId: integer("subject_id").references(() => subjects.id),
  durationMinutes: integer("duration_minutes").notNull(),
  date: timestamp("date").notNull().defaultNow(),
  notes: text("notes"),
});

export const subjectsRelations = relations(subjects, ({ many }) => ({
  tasks: many(tasks),
  studySessions: many(studySessions),
}));

export const tasksRelations = relations(tasks, ({ one }) => ({
  subject: one(subjects, {
    fields: [tasks.subjectId],
    references: [subjects.id],
  }),
}));

export const studySessionsRelations = relations(studySessions, ({ one }) => ({
  subject: one(subjects, {
    fields: [studySessions.subjectId],
    references: [subjects.id],
  }),
}));

export const insertSubjectSchema = createInsertSchema(subjects).omit({ id: true });
export const insertTaskSchema = createInsertSchema(tasks).omit({ id: true });
export const insertStudySessionSchema = createInsertSchema(studySessions).omit({ id: true, date: true });

export type Subject = typeof subjects.$inferSelect;
export type InsertSubject = z.infer<typeof insertSubjectSchema>;

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;

export type StudySession = typeof studySessions.$inferSelect;
export type InsertStudySession = z.infer<typeof insertStudySessionSchema>;

export type SubjectWithRelations = Subject & {
  tasks: Task[];
  studySessions: StudySession[];
};
