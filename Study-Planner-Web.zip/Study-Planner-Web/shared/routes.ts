import { z } from 'zod';
import { insertSubjectSchema, insertTaskSchema, insertStudySessionSchema, subjects, tasks, studySessions } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  subjects: {
    list: {
      method: 'GET' as const,
      path: '/api/subjects' as const,
      responses: {
        200: z.array(z.custom<typeof subjects.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/subjects/:id' as const,
      responses: {
        200: z.custom<typeof subjects.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/subjects' as const,
      input: insertSubjectSchema,
      responses: {
        201: z.custom<typeof subjects.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/subjects/:id' as const,
      input: insertSubjectSchema.partial(),
      responses: {
        200: z.custom<typeof subjects.$inferSelect>(),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/subjects/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  tasks: {
    list: {
      method: 'GET' as const,
      path: '/api/tasks' as const,
      input: z.object({
        subjectId: z.string().optional(),
        date: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof tasks.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/tasks' as const,
      input: insertTaskSchema,
      responses: {
        201: z.custom<typeof tasks.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/tasks/:id' as const,
      input: insertTaskSchema.partial(),
      responses: {
        200: z.custom<typeof tasks.$inferSelect>(),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/tasks/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
    autoSchedule: {
      method: 'POST' as const,
      path: '/api/tasks/auto-schedule' as const,
      input: z.object({
        subjectId: z.number(),
        hoursAvailable: z.number(),
        daysToDistribute: z.number(),
      }),
      responses: {
        200: z.array(z.custom<typeof tasks.$inferSelect>()),
        400: errorSchemas.validation,
      }
    }
  },
  studySessions: {
    list: {
      method: 'GET' as const,
      path: '/api/study-sessions' as const,
      responses: {
        200: z.array(z.custom<typeof studySessions.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/study-sessions' as const,
      input: insertStudySessionSchema,
      responses: {
        201: z.custom<typeof studySessions.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type SubjectInput = z.infer<typeof api.subjects.create.input>;
export type SubjectUpdateInput = z.infer<typeof api.subjects.update.input>;
export type SubjectResponse = z.infer<typeof api.subjects.create.responses[201]>;

export type TaskInput = z.infer<typeof api.tasks.create.input>;
export type TaskUpdateInput = z.infer<typeof api.tasks.update.input>;
export type TaskResponse = z.infer<typeof api.tasks.create.responses[201]>;

export type StudySessionInput = z.infer<typeof api.studySessions.create.input>;
export type StudySessionResponse = z.infer<typeof api.studySessions.create.responses[201]>;
