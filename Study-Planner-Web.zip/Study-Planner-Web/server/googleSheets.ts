import { google } from "googleapis";

export async function getGoogleSheetsClient() {
  const credentials = process.env.GOOGLE_CREDENTIALS;
  if (!credentials) {
    throw new Error("Missing GOOGLE_CREDENTIALS environment variable.");
  }

  try {
    const auth = new google.auth.GoogleAuth({
      credentials: JSON.parse(credentials),
      scopes: ["https://www.googleapis.com/auth/spreadsheets"],
    });
    return google.sheets({ version: "v4", auth });
  } catch (error: any) {
    throw new Error(`Failed to initialize Google Sheets client: ${error.message}`);
  }
}
