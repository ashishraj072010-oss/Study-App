import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { addDays, addHours, startOfDay, setHours } from "date-fns";
import type { InsertTask } from "@shared/schema";
import { getGoogleSheetsClient } from "./googleSheets";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // --- Google Sheets Test Route ---
  app.get("/test-sheet", async (req, res) => {
    try {
      const sheetId = process.env.SHEET_ID;
      if (!sheetId) {
        return res.status(400).json({ error: "Missing SHEET_ID environment variable." });
      }

      const sheets = await getGoogleSheetsClient();
      const response = await sheets.spreadsheets.values.get({
        spreadsheetId: sheetId,
        range: "Sheet1!A1:F100",
      });

      const rows = response.data.values;
      console.log("Sheet Data:", rows);

      if (!rows || rows.length === 0) {
        return res.json({ message: "No data found in sheet.", data: [] });
      }

      res.json({ message: "Successfully fetched sheet data", data: rows });
    } catch (error: any) {
      console.error("Google Sheets Error:", error);
      let message = "Failed to connect to Google Sheets";
      if (error.message?.includes("project not found")) message = "Invalid sheet ID or project not found";
      if (error.code === 403) message = "Sheet not shared with service account email";
      
      res.status(500).json({ 
        error: message,
        details: error.message 
      });
    }
  });

  // --- Subjects ---
  app.get(api.subjects.list.path, async (req, res) => {
    const subjects = await storage.getSubjects();
    res.json(subjects);
  });

  app.get(api.subjects.get.path, async (req, res) => {
    const subject = await storage.getSubject(Number(req.params.id));
    if (!subject) {
      return res.status(404).json({ message: 'Subject not found' });
    }
    res.json(subject);
  });

  app.post(api.subjects.create.path, async (req, res) => {
    try {
      const input = api.subjects.create.input.parse(req.body);
      const subject = await storage.createSubject(input);
      res.status(201).json(subject);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      throw err;
    }
  });

  app.put(api.subjects.update.path, async (req, res) => {
    try {
      const input = api.subjects.update.input.parse(req.body);
      const subject = await storage.updateSubject(Number(req.params.id), input);
      res.json(subject);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      throw err;
    }
  });

  app.delete(api.subjects.delete.path, async (req, res) => {
    await storage.deleteSubject(Number(req.params.id));
    res.status(204).end();
  });

  // --- Tasks ---
  app.get(api.tasks.list.path, async (req, res) => {
    const { subjectId, date } = req.query;
    const tasks = await storage.getTasks(
      subjectId ? Number(subjectId) : undefined,
      date as string | undefined
    );
    res.json(tasks);
  });

  app.post(api.tasks.create.path, async (req, res) => {
    try {
      // Coerce dates and numbers since they might come as strings from JSON/Forms
      const bodySchema = api.tasks.create.input.extend({
        scheduledDate: z.coerce.date(),
        subjectId: z.coerce.number().optional(),
      });
      const input = bodySchema.parse(req.body);
      const task = await storage.createTask(input);
      res.status(201).json(task);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      throw err;
    }
  });

  app.put(api.tasks.update.path, async (req, res) => {
    try {
      const bodySchema = api.tasks.update.input.extend({
        scheduledDate: z.coerce.date().optional(),
        subjectId: z.coerce.number().optional(),
      });
      const input = bodySchema.parse(req.body);
      const task = await storage.updateTask(Number(req.params.id), input);
      res.json(task);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      throw err;
    }
  });

  app.delete(api.tasks.delete.path, async (req, res) => {
    await storage.deleteTask(Number(req.params.id));
    res.status(204).end();
  });

  // Auto Task Scheduler
  app.post(api.tasks.autoSchedule.path, async (req, res) => {
    try {
      const input = api.tasks.autoSchedule.input.parse(req.body);
      const subject = await storage.getSubject(input.subjectId);
      
      if (!subject) {
        return res.status(400).json({ message: "Subject not found" });
      }

      // Simple scheduling algorithm: distribute hoursAvailable into 60-min chunks over daysToDistribute
      const totalTasksToCreate = Math.floor(input.hoursAvailable); // assuming 1 task = 1 hour (60 min)
      if (totalTasksToCreate <= 0) {
        return res.json([]);
      }

      const tasksToInsert: InsertTask[] = [];
      const baseDate = startOfDay(new Date());

      for (let i = 0; i < totalTasksToCreate; i++) {
        // distribute sequentially across the days requested
        const dayOffset = i % input.daysToDistribute;
        const taskDate = addDays(baseDate, dayOffset);
        // Distribute start times, say starting at 9 AM and spacing them by 2 hours
        const hourOffset = 9 + Math.floor(i / input.daysToDistribute) * 2;
        const scheduledDate = setHours(taskDate, hourOffset);

        tasksToInsert.push({
          subjectId: subject.id,
          title: `Study ${subject.name} - Part ${i + 1}`,
          scheduledDate: scheduledDate,
          durationMinutes: 60,
          isCompleted: false,
          priority: 3,
        });
      }

      const createdTasks = await storage.createMultipleTasks(tasksToInsert);
      res.json(createdTasks);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      throw err;
    }
  });

  // --- Study Sessions ---
  app.get(api.studySessions.list.path, async (req, res) => {
    const sessions = await storage.getStudySessions();
    res.json(sessions);
  });

  app.post(api.studySessions.create.path, async (req, res) => {
    try {
      const bodySchema = api.studySessions.create.input.extend({
        subjectId: z.coerce.number().optional(),
      });
      const input = bodySchema.parse(req.body);
      const session = await storage.createStudySession(input);
      res.status(201).json(session);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      throw err;
    }
  });

  // Seed Database on startup if empty
  seedDatabase().catch(console.error);

  return httpServer;
}

async function seedDatabase() {
  const subjects = await storage.getSubjects();
  if (subjects.length === 0) {
    const s1 = await storage.createSubject({ name: "Mathematics", targetHoursPerWeek: 5, color: "#3b82f6" });
    const s2 = await storage.createSubject({ name: "Physics", targetHoursPerWeek: 4, color: "#ef4444" });
    const s3 = await storage.createSubject({ name: "Literature", targetHoursPerWeek: 3, color: "#10b981" });

    const today = new Date();
    await storage.createTask({
      subjectId: s1.id,
      title: "Complete Calculus Set 1",
      scheduledDate: new Date(today.setHours(10, 0, 0, 0)),
      durationMinutes: 60,
      priority: 4,
      isCompleted: false,
    });

    await storage.createTask({
      subjectId: s2.id,
      title: "Review Kinematics Notes",
      scheduledDate: new Date(today.setHours(14, 0, 0, 0)),
      durationMinutes: 45,
      priority: 5,
      isCompleted: false,
    });

    await storage.createStudySession({
      subjectId: s1.id,
      durationMinutes: 30,
      notes: "Reviewed integration by parts.",
    });
  }
}
