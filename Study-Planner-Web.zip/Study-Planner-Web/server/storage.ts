import { db } from "./db";
import { eq, desc } from "drizzle-orm";
import {
  subjects,
  tasks,
  studySessions,
  type InsertSubject,
  type Subject,
  type InsertTask,
  type Task,
  type InsertStudySession,
  type StudySession,
} from "@shared/schema";
import type { SubjectUpdateInput, TaskUpdateInput } from "@shared/routes";

export interface IStorage {
  // Subjects
  getSubjects(): Promise<Subject[]>;
  getSubject(id: number): Promise<Subject | undefined>;
  createSubject(subject: InsertSubject): Promise<Subject>;
  updateSubject(id: number, updates: SubjectUpdateInput): Promise<Subject>;
  deleteSubject(id: number): Promise<void>;

  // Tasks
  getTasks(subjectId?: number, date?: string): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, updates: TaskUpdateInput): Promise<Task>;
  deleteTask(id: number): Promise<void>;
  createMultipleTasks(tasks: InsertTask[]): Promise<Task[]>;

  // Study Sessions
  getStudySessions(): Promise<StudySession[]>;
  createStudySession(session: InsertStudySession): Promise<StudySession>;
}

export class DatabaseStorage implements IStorage {
  // --- Subjects ---
  async getSubjects(): Promise<Subject[]> {
    return await db.select().from(subjects);
  }

  async getSubject(id: number): Promise<Subject | undefined> {
    const [subject] = await db.select().from(subjects).where(eq(subjects.id, id));
    return subject;
  }

  async createSubject(subject: InsertSubject): Promise<Subject> {
    const [created] = await db.insert(subjects).values(subject).returning();
    return created;
  }

  async updateSubject(id: number, updates: SubjectUpdateInput): Promise<Subject> {
    const [updated] = await db.update(subjects)
      .set(updates)
      .where(eq(subjects.id, id))
      .returning();
    return updated;
  }

  async deleteSubject(id: number): Promise<void> {
    await db.delete(subjects).where(eq(subjects.id, id));
  }

  // --- Tasks ---
  async getTasks(subjectId?: number, dateStr?: string): Promise<Task[]> {
    let query = db.select().from(tasks).$dynamic();
    
    if (subjectId !== undefined) {
      query = query.where(eq(tasks.subjectId, subjectId));
    }
    
    const results = await query.orderBy(tasks.scheduledDate);
    
    if (dateStr) {
      const filterDate = new Date(dateStr).toDateString();
      return results.filter(t => new Date(t.scheduledDate).toDateString() === filterDate);
    }
    
    return results;
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [created] = await db.insert(tasks).values(task).returning();
    return created;
  }

  async updateTask(id: number, updates: TaskUpdateInput): Promise<Task> {
    const [updated] = await db.update(tasks)
      .set(updates)
      .where(eq(tasks.id, id))
      .returning();
    return updated;
  }

  async deleteTask(id: number): Promise<void> {
    await db.delete(tasks).where(eq(tasks.id, id));
  }

  async createMultipleTasks(newTasks: InsertTask[]): Promise<Task[]> {
    if (newTasks.length === 0) return [];
    return await db.insert(tasks).values(newTasks).returning();
  }

  // --- Study Sessions ---
  async getStudySessions(): Promise<StudySession[]> {
    return await db.select().from(studySessions).orderBy(desc(studySessions.date));
  }

  async createStudySession(session: InsertStudySession): Promise<StudySession> {
    const [created] = await db.insert(studySessions).values(session).returning();
    return created;
  }
}

export const storage = new DatabaseStorage();
