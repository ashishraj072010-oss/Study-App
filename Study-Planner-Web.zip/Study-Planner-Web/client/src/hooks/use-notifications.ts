import { useState, useEffect } from "react";
import { useTasks } from "./use-tasks";

export function useNotifications() {
  const [permission, setPermission] = useState<NotificationPermission>("default");
  const { data: tasks } = useTasks();

  useEffect(() => {
    if ("Notification" in window) {
      setPermission(Notification.permission);
    }
  }, []);

  const requestPermission = async () => {
    if (!("Notification" in window)) return;
    const result = await Notification.requestPermission();
    setPermission(result);
  };

  // Monitor upcoming tasks
  useEffect(() => {
    if (permission !== "granted" || !tasks) return;

    const interval = setInterval(() => {
      const now = new Date();
      tasks.forEach((task: any) => {
        if (task.isCompleted) return;
        
        const taskTime = new Date(task.scheduledDate);
        const diffMs = taskTime.getTime() - now.getTime();
        const diffMins = Math.floor(diffMs / 60000);

        // Notify exactly 5 minutes before
        if (diffMins === 5) {
          new Notification("Upcoming Study Task", {
            body: `Your task "${task.title}" starts in 5 minutes!`,
            icon: "/favicon.png",
          });
        }
      });
    }, 60000); // Check every minute

    return () => clearInterval(interval);
  }, [tasks, permission]);

  return { permission, requestPermission };
}
