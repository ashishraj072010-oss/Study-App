import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type StudySessionInput } from "@shared/routes";

export function useStudySessions() {
  return useQuery({
    queryKey: [api.studySessions.list.path],
    queryFn: async () => {
      const res = await fetch(api.studySessions.list.path);
      if (!res.ok) throw new Error("Failed to fetch study sessions");
      return res.json();
    },
  });
}

export function useCreateStudySession() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: StudySessionInput) => {
      const res = await fetch(api.studySessions.create.path, {
        method: api.studySessions.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to log study session");
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.studySessions.list.path] }),
  });
}
