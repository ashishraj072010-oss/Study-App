import { motion } from "framer-motion";
import { format } from "date-fns";
import { AppLayout } from "@/components/layout/AppLayout";
import { useTasks } from "@/hooks/use-tasks";
import { useSubjects } from "@/hooks/use-subjects";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { CheckCircle2, Clock, BookOpen, Target } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Dashboard() {
  const { data: tasks } = useTasks();
  const { data: subjects } = useSubjects();

  const today = new Date();
  const todayStr = format(today, "EEEE, MMMM do");

  const pendingTasks = tasks?.filter((t: any) => !t.isCompleted) || [];
  const completedTasks = tasks?.filter((t: any) => t.isCompleted) || [];
  const totalTasks = tasks?.length || 0;
  const progressPercent = totalTasks > 0 ? (completedTasks.length / totalTasks) * 100 : 0;

  // Mock data for weekly chart
  const weeklyData = [
    { name: "Mon", hours: 2.5 },
    { name: "Tue", hours: 3.8 },
    { name: "Wed", hours: 1.5 },
    { name: "Thu", hours: 4.2 },
    { name: "Fri", hours: 2.0 },
    { name: "Sat", hours: 5.5 },
    { name: "Sun", hours: 3.0 },
  ];

  return (
    <AppLayout>
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">Welcome back! 👋</h1>
            <p className="text-muted-foreground mt-1">Here is your study overview for {todayStr}.</p>
          </div>
          <Button asChild className="rounded-xl shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-all">
            <Link href="/pomodoro">Start Study Session</Link>
          </Button>
        </div>

        {/* Top Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { title: "Total Pending", value: pendingTasks.length, icon: Clock, color: "text-amber-500" },
            { title: "Completed", value: completedTasks.length, icon: CheckCircle2, color: "text-emerald-500" },
            { title: "Active Subjects", value: subjects?.length || 0, icon: BookOpen, color: "text-primary" },
            { title: "Avg. Daily Hours", value: "3.2h", icon: Target, color: "text-purple-500" },
          ].map((stat, i) => (
            <Card key={i} className="hover-elevate border-border/50 bg-card/50 backdrop-blur-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Chart */}
          <Card className="lg:col-span-2 border-border/50 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg">Study Hours This Week</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={weeklyData}>
                    <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value}h`} />
                    <Tooltip cursor={{ fill: 'rgba(0,0,0,0.05)' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }} />
                    <Bar dataKey="hours" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Today's Tasks */}
          <Card className="border-border/50 shadow-sm flex flex-col">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Upcoming Tasks</CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/tasks">View All</Link>
              </Button>
            </CardHeader>
            <CardContent className="flex-1">
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Overall Progress</span>
                    <span className="font-medium">{Math.round(progressPercent)}%</span>
                  </div>
                  <Progress value={progressPercent} className="h-2" />
                </div>
                
                <div className="space-y-3 mt-6">
                  {pendingTasks.slice(0, 5).map((task: any) => (
                    <div key={task.id} className="flex items-center p-3 rounded-xl bg-muted/50 border border-border/50 transition-colors hover:bg-muted">
                      <div className="w-3 h-3 rounded-full bg-primary mr-3" />
                      <div className="flex-1 truncate">
                        <p className="text-sm font-medium truncate">{task.title}</p>
                        <p className="text-xs text-muted-foreground">{format(new Date(task.scheduledDate), 'h:mm a')} • {task.durationMinutes}m</p>
                      </div>
                    </div>
                  ))}
                  {pendingTasks.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      <CheckCircle2 className="w-10 h-10 mx-auto mb-2 text-muted" />
                      <p>All caught up for today!</p>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </motion.div>
    </AppLayout>
  );
}
