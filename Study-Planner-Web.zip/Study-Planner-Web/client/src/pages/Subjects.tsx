import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useSubjects, useCreateSubject, useDeleteSubject } from "@/hooks/use-subjects";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Trash2, BookOpen, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

export default function Subjects() {
  const { data: subjects, isLoading } = useSubjects();
  const createSubject = useCreateSubject();
  const deleteSubject = useDeleteSubject();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);

  const [name, setName] = useState("");
  const [hours, setHours] = useState("5");
  const [color, setColor] = useState("#3b82f6");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createSubject.mutateAsync({
        name,
        targetHoursPerWeek: parseInt(hours),
        color,
      });
      toast({ title: "Subject created successfully!" });
      setOpen(false);
      setName("");
    } catch (err) {
      toast({ title: "Error", description: "Failed to create subject", variant: "destructive" });
    }
  };

  return (
    <AppLayout>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Subjects</h1>
          <p className="text-muted-foreground">Manage your study subjects and weekly goals.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-xl shadow-md"><Plus className="w-4 h-4 mr-2" /> Add Subject</Button>
          </DialogTrigger>
          <DialogContent className="rounded-2xl">
            <DialogHeader>
              <DialogTitle>Add New Subject</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Subject Name</Label>
                <Input value={name} onChange={e => setName(e.target.value)} required className="h-11 rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label>Target Hours per Week</Label>
                <Input type="number" min="1" value={hours} onChange={e => setHours(e.target.value)} required className="h-11 rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label>Color Identity</Label>
                <div className="flex gap-2">
                  <Input type="color" value={color} onChange={e => setColor(e.target.value)} className="h-11 w-20 p-1 rounded-xl cursor-pointer" />
                  <Input type="text" value={color} onChange={e => setColor(e.target.value)} className="h-11 flex-1 rounded-xl uppercase font-mono" />
                </div>
              </div>
              <Button type="submit" className="w-full h-11 rounded-xl mt-4" disabled={createSubject.isPending}>
                Create Subject
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3].map(i => <div key={i} className="h-40 bg-muted/50 animate-pulse rounded-2xl" />)}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {subjects?.map((sub: any, i: number) => (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              key={sub.id}
            >
              <Card className="hover-elevate overflow-hidden border-border/50">
                <div className="h-2 w-full" style={{ backgroundColor: sub.color }} />
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-xl flex items-center gap-2">
                      <div className="p-2 rounded-lg" style={{ backgroundColor: `${sub.color}20`, color: sub.color }}>
                        <BookOpen className="w-5 h-5" />
                      </div>
                      {sub.name}
                    </CardTitle>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 -mt-2 -mr-2"
                      onClick={() => {
                        if (confirm('Delete this subject?')) deleteSubject.mutate(sub.id);
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold mt-2">{sub.targetHoursPerWeek}<span className="text-base font-normal text-muted-foreground"> hrs/week</span></p>
                  <div className="mt-4 bg-muted h-1.5 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: '45%', backgroundColor: sub.color }} />
                  </div>
                  <p className="text-xs text-muted-foreground mt-2 text-right">45% of weekly goal</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
          {subjects?.length === 0 && (
            <div className="col-span-full text-center py-20 bg-card rounded-2xl border border-dashed border-border/60">
              <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-medium">No subjects yet</h3>
              <p className="text-muted-foreground mt-1">Create your first subject to start tracking.</p>
            </div>
          )}
        </div>
      )}
    </AppLayout>
  );
}
