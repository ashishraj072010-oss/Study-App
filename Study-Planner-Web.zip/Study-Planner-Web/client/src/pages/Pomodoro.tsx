import { useState, useEffect } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useSubjects } from "@/hooks/use-subjects";
import { useCreateStudySession } from "@/hooks/use-study-sessions";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Play, Pause, RotateCcw, Coffee, Brain } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

const FOCUS_MINS = 25;
const BREAK_MINS = 5;

export default function Pomodoro() {
  const { data: subjects } = useSubjects();
  const createSession = useCreateStudySession();
  const { toast } = useToast();

  const [mode, setMode] = useState<'focus' | 'break'>('focus');
  const [timeLeft, setTimeLeft] = useState(FOCUS_MINS * 60);
  const [isActive, setIsActive] = useState(false);
  const [subjectId, setSubjectId] = useState<string>("");

  useEffect(() => {
    let interval: any;
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    } else if (isActive && timeLeft === 0) {
      setIsActive(false);
      handleComplete();
    }
    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  const handleComplete = async () => {
    // Play sound ideally
    if (mode === 'focus') {
      toast({ title: "Focus session complete!", description: "Time for a 5 minute break." });
      if (subjectId) {
        await createSession.mutateAsync({
          subjectId: parseInt(subjectId),
          durationMinutes: FOCUS_MINS,
          notes: "Pomodoro session",
        });
      }
      setMode('break');
      setTimeLeft(BREAK_MINS * 60);
    } else {
      toast({ title: "Break over!", description: "Ready to focus again?" });
      setMode('focus');
      setTimeLeft(FOCUS_MINS * 60);
    }
  };

  const toggleTimer = () => setIsActive(!isActive);
  
  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(mode === 'focus' ? FOCUS_MINS * 60 : BREAK_MINS * 60);
  };

  const mins = Math.floor(timeLeft / 60).toString().padStart(2, '0');
  const secs = (timeLeft % 60).toString().padStart(2, '0');
  const progress = 100 - (timeLeft / ((mode === 'focus' ? FOCUS_MINS : BREAK_MINS) * 60)) * 100;

  return (
    <AppLayout>
      <div className="max-w-2xl mx-auto pt-8">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold tracking-tight mb-2">Pomodoro Timer</h1>
          <p className="text-muted-foreground">Boost your productivity with focused study intervals.</p>
        </div>

        <Card className="p-8 sm:p-12 rounded-[2rem] border-border/50 shadow-xl shadow-primary/5 bg-card/50 backdrop-blur-xl relative overflow-hidden">
          {/* Progress Background */}
          <div 
            className="absolute bottom-0 left-0 h-1 bg-primary transition-all duration-1000 ease-linear"
            style={{ width: `${progress}%`, backgroundColor: mode === 'focus' ? 'hsl(var(--primary))' : 'hsl(142 71% 45%)' }}
          />

          <div className="flex justify-center gap-4 mb-10 relative z-10">
            <Button 
              variant={mode === 'focus' ? 'default' : 'ghost'} 
              className={`rounded-full px-6 transition-all ${mode === 'focus' ? 'shadow-md shadow-primary/25' : ''}`}
              onClick={() => { setMode('focus'); setTimeLeft(FOCUS_MINS * 60); setIsActive(false); }}
            >
              <Brain className="w-4 h-4 mr-2" /> Focus
            </Button>
            <Button 
              variant={mode === 'break' ? 'default' : 'ghost'} 
              className={`rounded-full px-6 transition-all ${mode === 'break' ? 'bg-emerald-500 hover:bg-emerald-600 shadow-md shadow-emerald-500/25' : ''}`}
              onClick={() => { setMode('break'); setTimeLeft(BREAK_MINS * 60); setIsActive(false); }}
            >
              <Coffee className="w-4 h-4 mr-2" /> Break
            </Button>
          </div>

          <div className="flex flex-col items-center justify-center relative z-10">
            <motion.div 
              key={`${mins}:${secs}`}
              initial={{ scale: 0.95, opacity: 0.8 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-8xl sm:text-[10rem] font-bold font-mono tracking-tighter tabular-nums mb-12"
              style={{ color: mode === 'focus' ? 'hsl(var(--foreground))' : 'hsl(142 71% 45%)' }}
            >
              {mins}:{secs}
            </motion.div>

            <div className="flex items-center gap-6 w-full max-w-sm justify-center">
              <Button 
                size="icon" 
                variant="outline" 
                className="w-14 h-14 rounded-full"
                onClick={resetTimer}
              >
                <RotateCcw className="w-6 h-6" />
              </Button>
              
              <Button 
                className={`w-20 h-20 rounded-full shadow-xl transition-all hover:scale-105 active:scale-95 ${
                  mode === 'focus' ? 'bg-primary hover:bg-primary/90 shadow-primary/30' : 'bg-emerald-500 hover:bg-emerald-600 shadow-emerald-500/30'
                }`}
                onClick={toggleTimer}
              >
                {isActive ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8 ml-1" />}
              </Button>
            </div>
          </div>

          {mode === 'focus' && (
            <div className="mt-12 max-w-xs mx-auto relative z-10">
              <Select value={subjectId} onValueChange={setSubjectId}>
                <SelectTrigger className="h-12 rounded-xl bg-background/50 backdrop-blur-sm">
                  <SelectValue placeholder="Assign session to subject..." />
                </SelectTrigger>
                <SelectContent>
                  {subjects?.map((sub: any) => (
                    <SelectItem key={sub.id} value={sub.id.toString()}>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: sub.color }}/>
                        {sub.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </Card>
      </div>
    </AppLayout>
  );
}
