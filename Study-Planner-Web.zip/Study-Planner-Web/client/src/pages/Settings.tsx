import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useNotifications } from "@/hooks/use-notifications";
import { Bell, Cloud, Laptop, FileDown } from "lucide-react";

export default function Settings() {
  const { toast } = useToast();
  const { permission, requestPermission } = useNotifications();

  const handleGoogleSheetsConnect = () => {
    toast({
      title: "Connecting to Google Sheets...",
      description: "Integration authorization is pending. Follow the Replit prompts.",
    });
  };

  return (
    <AppLayout>
      <div className="max-w-3xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
          <p className="text-muted-foreground">Manage integrations and app preferences.</p>
        </div>

        <Card className="border-border/50 rounded-2xl shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Cloud className="w-5 h-5 text-primary" /> Integrations
            </CardTitle>
            <CardDescription>Connect external services to sync your data.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-xl border border-border bg-muted/30">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-emerald-100 text-emerald-600 rounded-lg dark:bg-emerald-900/30 dark:text-emerald-400">
                  <FileDown className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-medium">Google Sheets Sync</h3>
                  <p className="text-sm text-muted-foreground">Export your study logs automatically.</p>
                </div>
              </div>
              <Button onClick={handleGoogleSheetsConnect} variant="outline" className="rounded-xl">
                Connect Account
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 rounded-2xl shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-primary" /> Notifications
            </CardTitle>
            <CardDescription>Configure how you receive reminders.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between p-4 rounded-xl border border-border bg-muted/30">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-blue-100 text-blue-600 rounded-lg dark:bg-blue-900/30 dark:text-blue-400">
                  <Laptop className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-medium">Browser Notifications</h3>
                  <p className="text-sm text-muted-foreground">
                    Status: <span className="font-semibold capitalize">{permission}</span>
                  </p>
                </div>
              </div>
              <Button 
                onClick={requestPermission} 
                disabled={permission === 'granted'}
                className="rounded-xl"
              >
                {permission === 'granted' ? 'Enabled' : 'Enable'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
