import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useTasks, useUpdateTask, useDeleteTask } from "@/hooks/use-tasks";
import { useSubjects } from "@/hooks/use-subjects";
import { AutoScheduleModal } from "@/components/AutoScheduleModal";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { format } from "date-fns";
import { Calendar as CalendarIcon, Clock, Trash2, Wand2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

export default function Tasks() {
  const { data: tasks, isLoading } = useTasks();
  const { data: subjects } = useSubjects();
  const updateTask = useUpdateTask();
  const deleteTask = useDeleteTask();
  const { toast } = useToast();
  
  const [autoScheduleOpen, setAutoScheduleOpen] = useState(false);
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('pending');

  const filteredTasks = tasks?.filter((t: any) => {
    if (filter === 'pending') return !t.isCompleted;
    if (filter === 'completed') return t.isCompleted;
    return true;
  }).sort((a: any, b: any) => new Date(a.scheduledDate).getTime() - new Date(b.scheduledDate).getTime());

  const getSubjectColor = (id: number) => subjects?.find((s:any) => s.id === id)?.color || "#ccc";
  const getSubjectName = (id: number) => subjects?.find((s:any) => s.id === id)?.name || "Unknown";

  const handleToggle = (id: number, current: boolean) => {
    updateTask.mutate({ id, isCompleted: !current }, {
      onSuccess: () => {
        if (!current) toast({ title: "Task completed!", description: "Great job keeping up with your studies." });
      }
    });
  };

  return (
    <AppLayout>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Tasks</h1>
          <p className="text-muted-foreground">Manage and track your study milestones.</p>
        </div>
        <div className="flex items-center gap-3 w-full md:w-auto">
          <Button 
            variant="outline" 
            className="flex-1 md:flex-none border-primary/20 bg-primary/5 hover:bg-primary/10 text-primary rounded-xl"
            onClick={() => setAutoScheduleOpen(true)}
          >
            <Wand2 className="w-4 h-4 mr-2" /> Auto-Schedule
          </Button>
        </div>
      </div>

      <div className="flex gap-2 mb-6 p-1 bg-muted/50 w-fit rounded-xl border border-border/50">
        {(['pending', 'completed', 'all'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 text-sm font-medium rounded-lg capitalize transition-all ${
              filter === f ? 'bg-background shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1,2,3].map(i => <div key={i} className="h-20 bg-muted/50 animate-pulse rounded-2xl" />)}
        </div>
      ) : (
        <div className="space-y-4">
          <AnimatePresence mode="popLayout">
            {filteredTasks?.map((task: any) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.2 } }}
                key={task.id}
              >
                <Card className={`overflow-hidden transition-all duration-300 hover:shadow-md ${task.isCompleted ? 'opacity-60 bg-muted/30' : 'bg-card'}`}>
                  <div className="flex items-center p-4 sm:p-5">
                    <div className="mr-4">
                      <Checkbox 
                        checked={task.isCompleted} 
                        onCheckedChange={() => handleToggle(task.id, task.isCompleted)}
                        className="w-6 h-6 rounded-full border-2 data-[state=checked]:bg-emerald-500 data-[state=checked]:border-emerald-500"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className={`text-lg font-medium truncate ${task.isCompleted ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
                        {task.title}
                      </h3>
                      <div className="flex flex-wrap items-center gap-3 mt-1 text-sm text-muted-foreground">
                        <Badge variant="outline" className="bg-background" style={{ borderColor: `${getSubjectColor(task.subjectId)}50`, color: getSubjectColor(task.subjectId) }}>
                          {getSubjectName(task.subjectId)}
                        </Badge>
                        <span className="flex items-center gap-1">
                          <CalendarIcon className="w-3 h-3" />
                          {format(new Date(task.scheduledDate), "MMM d")}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {task.durationMinutes} min
                        </span>
                      </div>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => deleteTask.mutate(task.id)}
                      className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 ml-2"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
          {filteredTasks?.length === 0 && (
            <div className="text-center py-20 text-muted-foreground border-2 border-dashed border-border/50 rounded-2xl bg-muted/10">
              <CheckSquare className="w-12 h-12 mx-auto mb-4 opacity-30" />
              <p>No tasks found in this view.</p>
            </div>
          )}
        </div>
      )}

      <AutoScheduleModal open={autoScheduleOpen} onOpenChange={setAutoScheduleOpen} />
    </AppLayout>
  );
}

// Ensure icon import works if missing
import { CheckSquare } from "lucide-react";
