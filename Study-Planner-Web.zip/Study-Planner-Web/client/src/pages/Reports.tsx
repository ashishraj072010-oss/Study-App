import { AppLayout } from "@/components/layout/AppLayout";
import { useStudySessions } from "@/hooks/use-study-sessions";
import { useSubjects } from "@/hooks/use-subjects";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend, AreaChart, Area, XAxis, YAxis } from "recharts";
import { format, subDays } from "date-fns";

export default function Reports() {
  const { data: sessions, isLoading: sessionsLoading } = useStudySessions();
  const { data: subjects, isLoading: subjectsLoading } = useSubjects();

  if (sessionsLoading || subjectsLoading) {
    return (
      <AppLayout>
        <div className="animate-pulse space-y-8">
          <div className="h-10 w-48 bg-muted rounded"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="h-80 bg-muted rounded-2xl"></div>
            <div className="h-80 bg-muted rounded-2xl"></div>
          </div>
        </div>
      </AppLayout>
    );
  }

  // Calculate subject distribution for Pie Chart
  const subjectTotals = sessions?.reduce((acc: any, session: any) => {
    acc[session.subjectId] = (acc[session.subjectId] || 0) + session.durationMinutes;
    return acc;
  }, {});

  const pieData = subjects?.map((sub: any) => ({
    name: sub.name,
    value: Math.round((subjectTotals[sub.id] || 0) / 60), // In hours
    color: sub.color
  })).filter((d: any) => d.value > 0) || [];

  // Calculate trend over last 7 days
  const last7Days = Array.from({ length: 7 }).map((_, i) => {
    const d = subDays(new Date(), 6 - i);
    return {
      date: format(d, 'MMM dd'),
      rawDate: format(d, 'yyyy-MM-dd'),
      minutes: 0
    };
  });

  sessions?.forEach((session: any) => {
    const sDate = format(new Date(session.date), 'yyyy-MM-dd');
    const day = last7Days.find(d => d.rawDate === sDate);
    if (day) {
      day.minutes += session.durationMinutes;
    }
  });

  const areaData = last7Days.map(d => ({
    date: d.date,
    hours: Number((d.minutes / 60).toFixed(1))
  }));

  const totalHours = pieData.reduce((acc: number, curr: any) => acc + curr.value, 0);

  return (
    <AppLayout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Analytics</h1>
        <p className="text-muted-foreground">Visualize your study habits and progress.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Time Distribution */}
        <Card className="border-border/50 shadow-sm rounded-2xl">
          <CardHeader>
            <CardTitle>Time Distribution (All Time)</CardTitle>
            <p className="text-sm text-muted-foreground">Total: {totalHours} hours studied</p>
          </CardHeader>
          <CardContent className="flex justify-center items-center h-[350px]">
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={80}
                    outerRadius={120}
                    paddingAngle={5}
                    dataKey="value"
                    stroke="none"
                  >
                    {pieData.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <RechartsTooltip 
                    formatter={(value: any) => [`${value} hours`, 'Studied']}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
                  />
                  <Legend verticalAlign="bottom" height={36}/>
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-muted-foreground">No study sessions recorded yet.</div>
            )}
          </CardContent>
        </Card>

        {/* 7-Day Trend */}
        <Card className="border-border/50 shadow-sm rounded-2xl">
          <CardHeader>
            <CardTitle>Study Trend (Last 7 Days)</CardTitle>
          </CardHeader>
          <CardContent className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={areaData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorHours" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(v) => `${v}h`} />
                <RechartsTooltip 
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
                />
                <Area type="monotone" dataKey="hours" stroke="hsl(var(--primary))" strokeWidth={3} fillOpacity={1} fill="url(#colorHours)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
