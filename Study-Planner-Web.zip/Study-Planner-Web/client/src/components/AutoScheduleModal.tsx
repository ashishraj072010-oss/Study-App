import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useSubjects } from "@/hooks/use-subjects";
import { useAutoScheduleTasks } from "@/hooks/use-tasks";
import { useToast } from "@/hooks/use-toast";

export function AutoScheduleModal({ 
  open, 
  onOpenChange 
}: { 
  open: boolean; 
  onOpenChange: (open: boolean) => void 
}) {
  const { data: subjects } = useSubjects();
  const autoSchedule = useAutoScheduleTasks();
  const { toast } = useToast();

  const [subjectId, setSubjectId] = useState<string>("");
  const [hours, setHours] = useState("5");
  const [days, setDays] = useState("7");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subjectId) {
      toast({ title: "Error", description: "Please select a subject", variant: "destructive" });
      return;
    }

    try {
      await autoSchedule.mutateAsync({
        subjectId: parseInt(subjectId),
        hoursAvailable: parseInt(hours),
        daysToDistribute: parseInt(days),
      });
      toast({ title: "Success", description: "Tasks auto-scheduled successfully!" });
      onOpenChange(false);
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px] rounded-2xl">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Auto-Schedule Tasks</DialogTitle>
          <DialogDescription>
            Let our AI distribute your study hours intelligently across the upcoming days.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 pt-4">
          <div className="space-y-2">
            <Label>Subject</Label>
            <Select value={subjectId} onValueChange={setSubjectId}>
              <SelectTrigger className="h-12 rounded-xl">
                <SelectValue placeholder="Select a subject" />
              </SelectTrigger>
              <SelectContent>
                {subjects?.map((sub: any) => (
                  <SelectItem key={sub.id} value={sub.id.toString()}>{sub.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Total Hours to Study</Label>
              <Input 
                type="number" 
                min="1" 
                value={hours} 
                onChange={(e) => setHours(e.target.value)}
                className="h-12 rounded-xl"
              />
            </div>
            <div className="space-y-2">
              <Label>Days to Distribute</Label>
              <Input 
                type="number" 
                min="1" 
                max="30" 
                value={days} 
                onChange={(e) => setDays(e.target.value)}
                className="h-12 rounded-xl"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              type="submit" 
              className="w-full h-12 text-base rounded-xl bg-gradient-to-r from-primary to-primary/80 hover:shadow-lg hover:shadow-primary/30 transition-all duration-300"
              disabled={autoSchedule.isPending}
            >
              {autoSchedule.isPending ? "Scheduling..." : "Generate Schedule"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
