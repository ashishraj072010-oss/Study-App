## Packages
date-fns | Used for date manipulation and formatting in the study planner
recharts | Used for generating beautiful progress and analytics charts
framer-motion | Used for page transitions and micro-interactions
next-themes | Used for handling dark/light mode switching

## Notes
Notifications rely on the native browser Notification API.
